#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ptrace.h>
#include <elf.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <dirent.h>
#include <sys/syscall.h>
#include <errno.h>
#include <link.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/user.h>
#include <sys/wait.h>
#include <udis86.h> //disas library
#include <stdarg.h>

#define MOV_EAX 0
#define MOV_EBX 1
#define MOV_ECX 2
#define MOV_EDX 3
#define MOV_ESI 4
#define MOV_EDI 5

#define RELOCATED_BASE 0x00C00000;

//flags for load_elf (last minute to fix problem)
#define READONLY 1
#define READ_WRITABLE 0

#define PAGEUP(x) (x + PAGE_SIZE - (x & (PAGE_SIZE - 1)))
#define PAGEDOWN(x) (x & ~(PAGE_SIZE - 1))

/*
 * Globals (Change this)
 */

struct globals {
	int libc_vma_size;
	char *libc_path;
	int pid;
	Elf64_Addr libc_addr;
} globals;

struct opts {
	int output;
	int reloc;
	int verbose;
	int static_elf;
} opts;

struct linking_info
{
	char *name;
        int index;
        int count;
        uint32_t r_offset;
        uint32_t r_info;
        uint32_t s_value;
        int r_type;
};

typedef struct pidmap {
	
	pid_t pid;

	Elf64_Ehdr *ehdr;
	Elf64_Phdr *phdr;
	uint32_t size;
	
	union {
		uint8_t *stack;
		uint8_t *heap;
	} data;
	
	Elf64_Word data_size;
        Elf64_Word text_size;
        Elf64_Addr data_vaddr;
        Elf64_Addr text_vaddr;
	Elf64_Addr libc_addr;
	Elf64_Addr stack_addr;
	Elf64_Addr stack_end;
	uint32_t libc_size;
        uint8_t *mem;
	
	struct linking_info *dlink;
	struct user_regs_struct regs;
		
	
} pidmap_t;

struct pltgot {
        Elf64_Addr *GOT;
        Elf64_Addr addr;        
};

typedef struct elfmap {
	Elf64_Ehdr *ehdr;
        Elf64_Phdr *phdr;
        Elf64_Shdr *shdr;
	uint32_t size;

	Elf64_Word data_size;
	Elf64_Word text_size;
	Elf64_Addr data_vaddr, data_vaddr_orig;
	Elf64_Addr text_vaddr, text_vaddr_orig;
	Elf64_Off text_offset;
	Elf64_Off data_offset;
	Elf64_Off entry_offset;
	Elf64_Addr rtext_vaddr;
	Elf64_Addr rdata_vaddr;

	struct stat st;
	char *StringTable;
	
	uint8_t *mem;
	
	Elf64_Addr relocbase;
	struct linking_info *dlink;
	char *outexec;
	char *name;
	
	struct pltgot pltgot;
} elfmap_t;


