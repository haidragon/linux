#include "possess.h"

#define MAX_RELOCS 256000

struct instdata {
	uint32_t offset;
	int len;
	const char *string;
	unsigned long op2;
} instdata;

struct relocData {
	uint8_t *relocPtr;
	unsigned long rval;
	unsigned long addr;
} relocData[MAX_RELOCS];
	
static unsigned int rcount = 0;

static unsigned long fixupAddr(unsigned long addr)
{
	unsigned long tmp, new;
	int diff;
	
	tmp = addr;
  	diff = (tmp >> 20) - 4;
    	new = 0x00C00000 >> 20;
      	new += diff;
   	new <<= 20;
     	tmp &= ~0x00FF0000;
        tmp |= new;
	
	return tmp;
}

/*
 * Fixup instructions:
 * MOV, JMP, SUB, ADD, CMP, CALL, PUSH
 */

int fixup_instructions(elfmap_t *elfmap)
{
	FILE *fd;
	ud_t ud_obj;
	uint64_t off;
	char *p, addrstr[32];
	int i, reloc_offset, diff;
	uint8_t *relocPtr;
	unsigned long relocAddr, tmp, new;
	
	ud_init(&ud_obj);
	ud_set_vendor(&ud_obj, UD_VENDOR_AMD);
	ud_set_mode(&ud_obj, 64);
	ud_set_input_buffer(&ud_obj, elfmap->mem, elfmap->st.st_size);
	ud_set_syntax(&ud_obj, UD_SYN_ATT);
		
	while(ud_disassemble(&ud_obj)) {
		instdata.len = ud_insn_len(&ud_obj);
		instdata.offset = ud_insn_off(&ud_obj);
		instdata.string = ud_insn_asm(&ud_obj);
		
		if (!strncasecmp(instdata.string,  "mov", 3)) {
			p = &instdata.string[4];
			if (p[0] != '$')
				continue;
			p++;
			for (i = 0; *p != ','; p++, i++) 
				addrstr[i] = *p;
			addrstr[i] = '\0';
			instdata.op2 = strtoul(addrstr, NULL, 16);
			if (!(instdata.op2 >= elfmap->text_vaddr_orig && instdata.op2 <= elfmap->data_vaddr_orig + elfmap->data_size)) 
				continue;
			reloc_offset = instdata.offset;
			reloc_offset += instdata.len - sizeof(uint32_t); 
			relocPtr = (uint8_t *)&elfmap->mem[reloc_offset];
			relocAddr = relocPtr[0] + (relocPtr[1] << 8) + (relocPtr[2] << 16) + (relocPtr[3] << 24);
			tmp = fixupAddr(relocAddr);
			relocData[rcount].relocPtr = relocPtr;
			relocData[rcount].rval = tmp;
			relocData[rcount].addr = elfmap->text_vaddr + reloc_offset;
			rcount++;
		//	*(unsigned long *)&relocPtr[0] = tmp;
		}  
		if (!strncasecmp(instdata.string, "jmp", 3)) {
			if ((p = strchr(instdata.string, '0')) == NULL)
				continue;
			if (strchr(p, '%'))  //make sure its not a jmp *off(%reg)
				continue;
			for (i = 0, p = p + 2; *p != '\0'; p++, i++)
				addrstr[i] = *p;
			addrstr[i] = '\0';
			instdata.op2 = strtoul(addrstr, NULL, 16);
			if (!(instdata.op2 >= elfmap->text_vaddr_orig && instdata.op2 <= elfmap->data_vaddr_orig + elfmap->data_size))
                                continue;
                        reloc_offset = instdata.offset;
			reloc_offset += instdata.len - sizeof(uint32_t);
			relocPtr = (uint8_t *)&elfmap->mem[reloc_offset];
                        relocAddr = relocPtr[0] + (relocPtr[1] << 8) + (relocPtr[2] << 16) + (relocPtr[3] << 24);
                        tmp = fixupAddr(relocAddr);
		  	relocData[rcount].relocPtr = relocPtr;
                        relocData[rcount].rval = tmp;
                        relocData[rcount].addr = elfmap->text_vaddr + reloc_offset;
                        rcount++;

		} 
		if (!strncasecmp(instdata.string, "sub", 3)) {
			if ((p = strchr(instdata.string, '$')) == NULL)
                                continue;
                        for (i = 0, p = p + 1; *p != '\0'; p++, i++)
                                addrstr[i] = *p;
                        addrstr[i] = '\0';
                        instdata.op2 = strtoul(addrstr, NULL, 16);
                        if (!(instdata.op2 >= elfmap->text_vaddr_orig && instdata.op2 <= elfmap->data_vaddr_orig + elfmap->data_size))
                                continue;
                        reloc_offset = instdata.offset;
                        reloc_offset += instdata.len - sizeof(uint32_t);
                        relocPtr = (uint8_t *)&elfmap->mem[reloc_offset];
			relocAddr = relocPtr[0] + (relocPtr[1] << 8) + (relocPtr[2] << 16) + (relocPtr[3] << 24);
                        tmp = fixupAddr(relocAddr);
                   	relocData[rcount].relocPtr = relocPtr;
                        relocData[rcount].rval = tmp;
                        relocData[rcount].addr = elfmap->text_vaddr + reloc_offset;
                        rcount++;

		}
		if (!strncasecmp(instdata.string, "add", 3)) {
                        p = &instdata.string[4];
			if (*p != '$')
				continue;
			for (i = 0, p = p + 1; *p != '\0'; p++, i++)
                                addrstr[i] = *p;
                        addrstr[i] = '\0';
                        instdata.op2 = strtoul(addrstr, NULL, 16);
                        if (!(instdata.op2 >= elfmap->text_vaddr_orig && instdata.op2 <= elfmap->data_vaddr_orig + elfmap->data_size))
                                continue;
                        reloc_offset = instdata.offset;
                        reloc_offset += instdata.len - sizeof(uint32_t);
                        relocPtr = (uint8_t *)&elfmap->mem[reloc_offset];
                        relocAddr = relocPtr[0] + (relocPtr[1] << 8) + (relocPtr[2] << 16) + (relocPtr[3] << 24);
                        tmp = fixupAddr(relocAddr);
                	relocData[rcount].relocPtr = relocPtr;
                        relocData[rcount].rval = tmp;
                        relocData[rcount].addr = elfmap->text_vaddr + reloc_offset;
                        rcount++;

		} 

	}
	for (i = 0; i < rcount; i++) {
		*(unsigned int *)&(relocData[i].relocPtr)[0] = relocData[i].rval;
	//	printf("Applied relocation at address 0x%lx with value 0x%lx\n", relocData[i].addr, relocData[i].rval);
	}

}
	
	
