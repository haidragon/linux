#include <stdio.h>

int main(void)
{
	for(;;) {
		printf("I am a boring program\n");
		sleep(3);
	}
	 
}
