#include "possess.h"

unsigned long get_stack_addr(int pid)
{
	FILE *fd;
	char buf[255], file[255];
	char *p;
	char addrstr[32];
	int i;
	unsigned long stack_bottom;

	snprintf(file, sizeof(file)-1, "/proc/%d/maps", pid);
	
	if ((fd = fopen(file, "r")) == NULL) {
		printf("fopen %s: %s\n", file, strerror(errno));
		exit(-1);
	}

	while (fgets(buf, sizeof(buf), fd)) {
		if (strstr(buf, "[stack]")) {
			if ((p = strchr(buf, '-'))) {
				p++;
				for (i = 0; *p != 0x20; p++, i++)
					addrstr[i] = *p;
				addrstr[i] = '\0';
				stack_bottom = strtoul(addrstr, NULL, 16);
				return stack_bottom;
			}
		}
	}
	return 0;
}
				
			
unsigned long get_libc_addr(int pid)
{
        FILE *fd;
        char buf[255], file[255];
        char *p, *q;
        Elf64_Addr start, stop;

        snprintf(file, sizeof(file)-1, "/proc/%d/maps", pid);
        
        if ((fd = fopen(file, "r")) == NULL) {
                printf("fopen %s: %s\n", file, strerror(errno));
                exit(-1);
        }
        
        while (fgets(buf, sizeof(buf), fd)) {
                if (strstr(buf, "libc") && strstr(buf, ".so")) {
                        if ((p = strchr(buf, '-'))) 
                                *p = '\0';
                        
                        start = strtoul(buf, NULL, 16);
                        p++;
                        stop = strtoul(p, NULL, 16);
                        
                        globals.libc_vma_size = stop - start;
                        /* While we're at it get the path too */
                        while (*p != '/')
                                p++;
                        *(char *)strchr(p, '\n') = '\0';
                        globals.libc_path = strdup(p);
                        if (!globals.libc_path) {
                                perror("strdup");
                                exit(-1);
                        }
			globals.libc_addr = start;
                        return start;
                }
        }

}


