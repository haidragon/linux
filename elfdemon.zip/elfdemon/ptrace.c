#include "possess.h"

int pid_write(int pid, void *dest, const void *src, size_t len)
{
        size_t rem = len % sizeof(void *);
        size_t quot = len / sizeof(void *);
        unsigned char *s = (unsigned char *) src;
        unsigned char *d = (unsigned char *) dest;
	long w;
	
        while (quot-- != 0) {
                if ( ptrace(PTRACE_POKEDATA, pid, d, *(long *)s) == -1 )
                        goto err;
                s += sizeof(unsigned long);
                d += sizeof(unsigned long);
        }

return 0;
err:
        return -1;
}

int pid_read(int pid, void *dst, const void *src, size_t len)
{

        int sz = len / sizeof(void *);
        int rem = len % sizeof(void *);
        unsigned char *s = (unsigned char *)src;
        unsigned char *d = (unsigned char *)dst;
        long word;
        
        while (sz-- != 0) {
                word = ptrace(PTRACE_PEEKTEXT, pid, s, NULL);
                if (word == -1 && errno) 
                        return -1;
         
               *(long *)d = word;
                s += sizeof(long);
                d += sizeof(long);
        }
        
        return 0;
}

int pid_attach(int pid)
{
	if (ptrace(PTRACE_ATTACH, pid, NULL, NULL) < 0) {
		perror("ptrace");
		return -1;
	}
	wait(NULL);

	return 0;
}

int pid_detach(int pid)
{
	if (ptrace(PTRACE_DETACH, pid, NULL, NULL) < 0) {
		perror("ptrace");
		return -1;
	}
	wait(NULL);

	return 0;

}




