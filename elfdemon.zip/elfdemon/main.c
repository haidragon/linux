#include "possess.h"

Elf64_Addr get_orig_host_main(int pid)
{
	char *p, exec_path[255], path[255], buf[512];
	FILE *fd;
	int i;
	elfmap_t elf;
	Elf64_Addr vaddr;

	snprintf(path, 254, "/proc/%d/maps", pid);
	
	if ((fd = fopen(path, "r")) == NULL) {
		printf("Unable to open %s: %s\n", path, strerror(errno));
		exit(-1);
	}
	
	fgets(buf, sizeof(buf), fd);
	p = strchr(buf, '/');
	while (*p != '\n' && *p != 0x20 && *p != '\0') {
		exec_path[i++] = *p;
		p++;
	}
	exec_path[i] = '\0';
	fclose(fd);
	
	load_elf(exec_path, &elf, 1);
	vaddr = get_sym_value(&elf, "main");
	return vaddr;
}
	
	
void systemFMT(char *str, ...)
{
        char string[255];
        va_list va;

        va_start (va, str);
        vsnprintf (string, 255, str, va);
        va_end (va);

        system(string);
}

int main(int argc, char **argv)
{
	elfmap_t exec;
	pidmap_t proc;
	int c;
	char tmp[512], *p;
	Elf64_Addr address_of_main;

usage:
	if (argc < 3) {
		printf("Usage: %s <executable> <pid> [opts]\n"
		       "-r	Relocatable base\n"	
		       "-o	Write relocated executable into output exec\n"
		       "-v	Verbose output\n", argv[0]);
		exit(0);
	}
	
	exec.name = argv[1];
	globals.pid = proc.pid = atoi(argv[2]);
	
	memset(&opts, 0, sizeof(opts));

	while ((c = getopt(argc, argv, "r:o:v")) != -1) {
		switch(c) {
			case 'r':
				opts.reloc = 1;
				exec.relocbase = strtoul(optarg, NULL, 16);
				break;
			case 'o':
				opts.output = 1;
				exec.outexec = strdup(optarg);
				break;
			case 'v':
				opts.verbose = 1;
				break;
			default:
				goto usage;
		}
	}
	
	char *origpath = argv[1];
	if ((p = strrchr(exec.name, '/')) != NULL) {
		p++;
		exec.name = strdup(p);
	}
	systemFMT("/bin/cp %s /tmp/%s.rel", origpath, exec.name);
 	snprintf(tmp, sizeof(tmp), "/tmp/%s.rel", exec.name);
	exec.name = strdup(tmp);

	if (access(tmp, W_OK)) {
		fprintf(stderr, "Unable to access %s which is needed to create a relocated executable. %s \n", tmp, strerror(errno));
		exit(-1);
	}
	
	/**** If the process you are injecting into for some reason has no binary ***/
	/* on the system anymore, then comment this next line out, but beware that the */
	/* evil program you are injecting will not be able to pass control back to the */
	/* host executable when it is done. 					       */
	unsigned long address_of_main_in_host = get_orig_host_main(globals.pid);

	if (load_elf(exec.name, &exec, 0) < 0) {
		fprintf(stderr, "Failed at loading %s: %s\n", exec.name, strerror(errno));
		exit(-1);
	}
	
	
	if (fixup_instructions(&exec) < 0) {
                fprintf(stderr, "Failed at fixing up instructions\n");
                exit(-1);
        }

	fixup_ehdr(&exec);

	/*
	 * Fixup dynamic segment and GOT before we
	 * cluster fuck everything with fixup_phdrs and fixup_shdrs
	 */
	
	if (fixup_dynamic_segment(&exec) < 0) {
		fprintf(stderr, "Failed at fixing up dynamic segment\n");
		exit(-1);
	}

	if (fixup_got(&exec) < 0) {
		fprintf(stderr, "Failed at fixing up G.O.T\n");
		exit(-1);
	}
	
	if (fixup_phdrs(&exec) < 0) {
                fprintf(stderr, "Failed at fixing up ELF program headers\n");
                exit(-1);
        }

        if (fixup_shdrs(&exec) < 0) {
                fprintf(stderr, "Failed at fixing up ELF section headers\n");
                exit(-1);
        }
	
	address_of_main = get_sym_value(&exec, "main");
	
	inject_executable(&exec, address_of_main, address_of_main_in_host);

	
	
}

