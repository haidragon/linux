#include "possess.h"

int load_elf(const char *path, elfmap_t *elf, int rdonly)
{
	int fd, i;
	
	int open_flags = O_RDWR;

	if (rdonly)
		open_flags = O_RDONLY;

	if ((fd = open(path, open_flags)) < 0) {
		perror("open");
		return -1;
	}

	if (fstat(fd, &elf->st) < 0) {
		perror("open");
		return -1;
	}
	if (rdonly) 
		elf->mem = mmap(NULL, elf->st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
	else
		elf->mem = mmap(NULL, elf->st.st_size, PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0); 
	if (elf->mem == MAP_FAILED) {
		perror("mmap");
		exit(-1);
	}
	
	if (elf->mem[0] != 0x7f && strcmp(&elf->mem[1], "ELF")) {
		fprintf(stderr, "[!] %s is not an ELF file\n", path);
		return -1;
	}

	elf->ehdr = (Elf64_Ehdr *)elf->mem;
	elf->phdr = (Elf64_Phdr *)&elf->mem[elf->ehdr->e_phoff];
	elf->shdr = (Elf64_Shdr *)&elf->mem[elf->ehdr->e_shoff];
	
	if (elf->ehdr->e_type != ET_EXEC) {
		fprintf(stderr, "[!] %s is not an ELF executable\n", path);
		return -1;
	}
	
	if (elf->ehdr->e_machine != EM_X86_64) {
		fprintf(stderr, "[!] %s is not an X86_64 ELF Executable\n", path);
		return -1;
	}

	elf->StringTable = &elf->mem[elf->shdr[elf->ehdr->e_shstrndx].sh_offset]; 
	
	for (i = 0; i < elf->ehdr->e_phnum; i++) {
		if (elf->phdr[i].p_offset == 0 && elf->phdr[i].p_flags == (PF_R|PF_X)) {
			elf->text_vaddr_orig = elf->text_vaddr = elf->phdr[i].p_vaddr;
			elf->text_size = elf->phdr[i].p_memsz;
			elf->text_offset = elf->phdr[i].p_offset;
			elf->data_vaddr_orig = elf->data_vaddr = elf->phdr[i + 1].p_vaddr;
			elf->data_size = elf->phdr[i + 1].p_memsz;
			elf->data_offset = elf->phdr[i + 1].p_offset;
			break;
		}
	}
	
	return 0;
}

Elf64_Addr get_sym_value(elfmap_t *target, char *string)
{
	int i, j;
	char *SymStrTable;
	Elf64_Sym *symtab;

	for (i = 0; i < target->ehdr->e_shnum; i++) {
        	if (target->shdr[i].sh_type == SHT_SYMTAB) {
                        SymStrTable = (char *)&target->mem[target->shdr[target->shdr[i].sh_link].sh_offset];
                        symtab = (Elf64_Sym *)&target->mem[target->shdr[i].sh_offset];
			for (j = 0; j < target->shdr[i].sh_size / sizeof(Elf64_Sym); j++, symtab++) {
				if (!strcmp(&SymStrTable[symtab->st_name], string))
					return symtab->st_value;
			}
		}
	}

	return 0;
}

void fixup_ehdr(elfmap_t *elfmap)
{
	int diff;
	Elf64_Addr new, tmp;
	

	if (elfmap->ehdr->e_entry > 0x004FFFFF) {
		tmp = elfmap->ehdr->e_entry;
		diff = (tmp >> 20) - 4;
		new = 0x00C00000 >> 20;
		new += diff;
		new <<= 20;
		tmp &= ~0x00FF0000;
		tmp |= new;
		elfmap->ehdr->e_entry = tmp;
		return;
	} 
	elfmap->ehdr->e_entry &= ~0x00FF0000;
	elfmap->ehdr->e_entry |= 0x00C00000;
}

int fixup_shdrs(elfmap_t *elfmap)
{
	int i, diff;
	Elf64_Addr tmp = 0;
	Elf64_Addr new;
	
	for (i = 0; i < elfmap->ehdr->e_shnum; i++) {
		if (elfmap->shdr[i].sh_addr == 0)
			continue;
		if (elfmap->shdr[i].sh_addr > 0x004FFFFF) {
			tmp = elfmap->shdr[i].sh_addr;
			diff = (tmp >> 20) - 4;
			new = 0x00C00000 >> 20;
			new += diff;
			new <<= 20;
			tmp &= ~0x00FF0000;
			tmp |= new;
			elfmap->shdr[i].sh_addr = tmp;
		} else {
			tmp = elfmap->shdr[i].sh_addr & ~0x00FF0000;
			tmp |= 0x00C00000;
			elfmap->shdr[i].sh_addr = tmp;
		}
		
	}
	return tmp == 0 ? -1 : 0;
}

int fixup_phdrs(struct elfmap *elfmap)
{

	int i, diff;
	Elf64_Addr tmp = 0;
	Elf64_Addr new;

	for (i = 0; i < elfmap->ehdr->e_phnum; i++) {
		/* 
		 * text and data segment use the same operation 
		 * I.E 0x8048000 is changed to 0xc048000 
		 */
		if (elfmap->phdr[i].p_vaddr > 0x004FFFFF) {
			tmp = elfmap->phdr[i].p_vaddr;
                        diff = (tmp >> 20) - 4;
                        new = 0x00C00000 >> 20;
                        new += diff;
                        new <<= 20;
                        tmp &= ~0x00FF0000;
                        tmp |= new;
			elfmap->phdr[i].p_vaddr = tmp;
			elfmap->phdr[i].p_paddr = tmp;
		} else {
			tmp = elfmap->phdr[i].p_vaddr & ~(0x00FF0000);
			tmp |= 0x00C00000;
			elfmap->phdr[i].p_vaddr = tmp;
			elfmap->phdr[i].p_paddr = tmp;
		}
		
	}
	return tmp == 0 ? -1 : 0;
}

int fixup_dynamic_segment(elfmap_t *elfmap)
{
        Elf64_Dyn *dyn;
        int i, diff;	
	unsigned long new;
        
        for (i = 0; i < elfmap->ehdr->e_phoff; i++)
                if (elfmap->phdr[i].p_type == PT_DYNAMIC) {
                        dyn = (Elf64_Dyn *)(elfmap->mem + elfmap->phdr[i].p_offset);
                        break;
                }

        if (!dyn) 
               return -1;
	
	/*
	 * Catch every tag that has a memory address
	 * value so we can adjust it to meet our new
	 * relocation base requirements.
	 */
        for (i = 0; dyn[i].d_tag != DT_NULL; i++)
                switch(dyn[i].d_tag) {
                        case DT_NEEDED:
                        case DT_INIT:
                        case DT_FINI:
                        case DT_GNU_HASH:
                        case DT_STRTAB:
                        case DT_SYMTAB:
                        case DT_PLTGOT:
                        case DT_JMPREL:
                        case DT_REL:
			case DT_RELA:
                        case DT_VERNEED:
                        case DT_VERSYM: 
				if (dyn[i].d_un.d_val > 0x004FFFFF) {
					diff = (dyn[i].d_un.d_val >> 20) - 4;
					new = 0x00C00000 >> 20;
					new += diff;
					new <<= 20;
					dyn[i].d_un.d_val &= ~0x00FF0000;
					dyn[i].d_un.d_val |= new;
				} else {			
                                	dyn[i].d_un.d_val &= ~0x00FF0000;
                                	dyn[i].d_un.d_val |= 0x00C00000;
				}
                        	break;
                }
                        
}

/* 
 * We don't need fixup_plt_stubs on x86_64
 * thanks to the jmpq *off(%rip) instructions
 */
int fixup_plt_stubs(elfmap_t *elfmap)
{
        int i, plt_size;
        Elf64_Addr plt_offset = 0;
        uint8_t *mem;
        Elf64_Addr tmp;

        for (i = 0; i < elfmap->ehdr->e_shnum; i++)
                if (!strcmp(&elfmap->StringTable[elfmap->shdr[i].sh_offset], ".plt")) {
                        plt_offset = elfmap->shdr[i].sh_offset;
                        plt_size = elfmap->shdr[i].sh_size;
                        break;
                }
        
        if (plt_offset == 0) 
                return -1;
                
        for (i = plt_offset, mem = &elfmap->mem[i]; i < plt_offset + plt_size; i++) {
                
                /*
                 * If we see an indirect jmp (jmp *addr) we can safely assume
                 * that it is an indirect jmp into the GOT
  		 * NOTE: This is assuming 32BIT ELF
                 */
                if (mem[i] == 0xff && mem[i + 4] == 0x08) {
                        tmp = mem[i + 1] + (mem[i + 2] << 8) + (mem[i + 3] << 16) +(mem[i + 4] << 24);
                        tmp &= ~(0xFF000000);
                        tmp |= 0x0C000000;
                        *(Elf64_Addr *)&mem[i + 3] = tmp;
                }
        }
        return 0;                       
                        
}


char * get_section_index(int section, uint8_t *target)
{
        
        int i;
        Elf64_Ehdr *ehdr = (Elf64_Ehdr *)target;
        Elf64_Shdr *shdr = (Elf64_Shdr *)(target + ehdr->e_shoff);
        
        for (i = 0; i < ehdr->e_shnum; i++) {
                if (i == section)
                        return (target + shdr[i].sh_offset);
        }

}

Elf64_Addr resolve_symbol(char *name, uint8_t *target)
{
        Elf64_Sym *symtab;
        char *SymStrTable;
        int i, j, symcount;

        Elf64_Off strtab_off;
        Elf64_Ehdr *ehdr = (Elf64_Ehdr *)target;
        Elf64_Shdr *shdr = (Elf64_Shdr *)(target + ehdr->e_shoff);

        for (i = 0; i < ehdr->e_shnum; i++) {
                if (shdr[i].sh_type == SHT_SYMTAB || shdr[i].sh_type == SHT_DYNSYM) {
                        /* 
                         * In this instance of the sh_link member of Elf64_Shdr, it points
                         * to the section header index of the symbol table string table section.
                         */
                        SymStrTable = (char *)get_section_index(shdr[i].sh_link, target);
                        symtab = (Elf64_Sym *)get_section_index(i, target);
                        for (j = 0; j < shdr[i].sh_size / sizeof(Elf64_Sym); j++, symtab++) {
                                if(strcmp(&SymStrTable[symtab->st_name], name) == 0) {
                                        return (symtab->st_value);
                                }
                        }
                }
        }
        return 0;
} 

struct linking_info *retrieve_got_info(struct elfmap *target)
{
        Elf64_Shdr *shdr, *shdrp, *symshdr;
        Elf64_Sym *syms, *symsp;
        Elf64_Rel *rel;
        Elf64_Ehdr *ehdr;

        char *symbol;
        int i, j, symcount, k;

        struct linking_info *link;

        uint8_t *mem = (uint8_t *)target->mem;

        ehdr = (Elf64_Ehdr *)mem;
        shdr = (Elf64_Shdr *)(mem + ehdr->e_shoff);

        shdrp = shdr;

        for (i = ehdr->e_shnum; i-- > 0; shdrp++) {
                if (shdrp->sh_type == SHT_DYNSYM) {
                        symshdr = &shdr[shdrp->sh_link];
                        if ((symbol = malloc(symshdr->sh_size)) == NULL)
                                goto fatal;
                        memcpy(symbol, (mem + symshdr->sh_offset), symshdr->sh_size);

                        if ((syms = (Elf64_Sym *)malloc(shdrp->sh_size)) == NULL)
                                goto fatal;

                        memcpy((Elf64_Sym *)syms, (Elf64_Sym *)(mem + shdrp->sh_offset), shdrp->sh_size);
                        symsp = syms;

                        symcount = (shdrp->sh_size / sizeof(Elf64_Sym));
                        link = (struct linking_info *)malloc(sizeof(struct linking_info) * symcount);
                        if (!link)
                                goto fatal;
                        link[0].count = symcount;
                        for (j = 0; j < symcount; j++, symsp++) {
                                link[j].name = strdup(&symbol[symsp->st_name]);
                                if (!link[j].name)
                                        goto fatal;
                                link[j].s_value = symsp->st_value;
                                link[j].index = j;
                        }
                        break;
   }
        }
        for (i = ehdr->e_shnum; i-- > 0; shdr++) {
                switch(shdr->sh_type) {
                        case SHT_RELA:
                                 rel = (Elf64_Rel *)(mem + shdr->sh_offset);
                                 for (j = 0; j < shdr->sh_size; j += sizeof(Elf64_Rel), rel++) {
                                        for (k = 0; k < symcount; k++) {
                                                if (ELF64_R_SYM(rel->r_info) == link[k].index) {
                                                        link[k].r_offset = rel->r_offset;
                                                        link[k].r_info = rel->r_info;
                                                        link[k].r_type = ELF64_R_TYPE(rel->r_info);
                                                }

                                        }
                                 }
                                 break;
                        case SHT_REL:
				 rel = (Elf64_Rel *)(mem + shdr->sh_offset);
                                 for (j = 0; j < shdr->sh_size; j += sizeof(Elf64_Rel), rel++) {
                                        for (k = 0; k < symcount; k++) {
                                                if (ELF64_R_SYM(rel->r_info) == link[k].index) {
                                                        link[k].r_offset = rel->r_offset;
                                                        link[k].r_info = rel->r_info;
                                                        link[k].r_type = ELF64_R_TYPE(rel->r_info);
                                                }

                                        }
                                 }

                                break;

                        default:
                                break;
                }
        }

        return link;
        fatal:
                return NULL;
}

void load_got_info_via_shdrs(elfmap_t *elfmap)
{
	int i;
	for (i = 0; i < elfmap->ehdr->e_shnum; i++) {
		if (!strcmp(&(elfmap->StringTable[elfmap->shdr[i].sh_name]), ".got.plt")) {
			elfmap->pltgot.GOT = (Elf64_Addr *)&elfmap->mem[elfmap->shdr[i].sh_offset];
			elfmap->pltgot.addr = elfmap->shdr[i].sh_addr;
			break; 
		}
	}
}

int fixup_got(struct elfmap *elfmap)
{
        int i;
        struct linking_info *link;
	Elf64_Addr got_sym_addr, symaddr;
 	Elf64_Addr libc_addr, tmp;
	unsigned int libc_sym_addr;
        
	load_got_info_via_shdrs(elfmap);
	
        link = retrieve_got_info(elfmap);
  	if (!link) {
                printf("Unable to resolve Global offset table symbols\n");
                exit(-1);
        }

        get_libc_addr(globals.pid);
	printf("libc: %lx\n", globals.libc_addr);

        int fd;
        struct stat st;

        if ((fd = open(globals.libc_path, O_RDONLY)) < 0) {
                perror("open libc");
                exit(-1);
        }

        if (fstat(fd, &st) < 0) {
                perror("fstat");
                exit(-1);
        }
	
	/*
	 * Map libc into memory, and resolve its symbols.
	 */
        uint8_t *libcp = mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
        for (i = 0; i < link[0].count; i++) {
                if (link[i].r_offset < 0x00400000) 
			continue;
		libc_sym_addr = resolve_symbol(link[i].name, libcp);
		tmp = libc_sym_addr + globals.libc_addr;
  		elfmap->pltgot.GOT[i + 2] = tmp;
   		printf("GOT[%d](%s) -> %p\n", i, link[i].name, elfmap->pltgot.GOT[i + 2]);
        }                               
         
	munmap(libcp, st.st_size);       
	close(fd);

        return 0;
}



